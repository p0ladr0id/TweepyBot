import tweepy
import random
#Make your tweets from line 28-104
#Variables for the keys provided by twitter and authenticates to twitter
API_KEY = "Null"
API_SECRET_KEY = "Null"

Access_Token = "Null"
Secret_Access_Token = "Null"

#Authorization
auth = tweepy.OAuthHandler(API_KEY, API_SECRET_KEY)
auth.set_access_token(Access_Token, Secret_Access_Token)

api = tweepy.API(auth)


#Program status messages
try:
    api.verify_credentialsinput
    print("Everything Works")
except:
    print("Something Went Wrong")



#Makes the tweet and displays if it was tweeted or not
#############################################################################

tweetnmb = random.randint(0, 4)
# 0 = Null  1 = Null  2 = Null  3 = Null  4 = Null


#Null picker
post0nmb = random.randint(0, 3)
if post0nmb == 0:
    tweet = ("InsertTweet")
if post0nmb == 1:
    tweet = ("InsertTweet")
if post0nmb == 2:
    tweet = ("InsertTweet")
if post0nmb == 3:
    tweet = ("InsertTweet")
#Tweet with picked Null
if tweetnmb == 0:
    finaltweet = (tweet)

#Null picker
post1nmb = random.randint(0, 3)
if post1nmb == 0:
    tweet = ("InsertTweet")
if post1nmb == 1:
    tweet = ("InsertTweet")
if post1nmb == 2:
    tweet = ("InsertTweet")
if post1nmb == 3:
    tweet = ("InsertTweet")
#Tweet with picked Null
if tweetnmb == 1:
    finaltweet = (tweet)

#Null picker
post2nmb = random.randint(0, 3)
if post2nmb == 0:
    tweet = ("InsertTweet")
if post2nmb == 1:
    tweet = ("InsertTweet")
if post2nmb == 2:
    tweet = ("InsertTweet")
if post2nmb == 3:
    tweet = ("InsertTweet")
#Tweets the picked release
if tweetnmb == 2:
    finaltweet = (tweet)

#Null picker
post3nmb = random.randint(0, 3)
if post3nmb == 0:
    tweet = ("InsertTweet")
if post3nmb == 1:
    tweet = ("InsertTweet")
if post3nmb == 2:
    tweet = ("InsertTweet")
if post3nmb == 3:
    tweet = ("InsertTweet")
#Tweets the picked indie
if tweetnmb == 3:
    finaltwwet = (tweet)

#Null picker
post4nmb = random.randint(0, 3)
if post4nmb == 0:
    tweet = ("InsertTweet")
if post4nmb == 1:
    tweet = ("InsertTweet")
if post4nmb == 2:
    tweet = ("InsertTweet")
if post4nmb == 3:
    tweet = ("InsertTweet")
#Tweets the picked Null
if tweetnmb == 4:
    finaltweet = (tweet)

#############################################################################

tweetstatsuc = "Tweeted"
tweetstatfail = "Couldn't Tweet"
try:
    api.update_status(finaltweet)
    print(tweetstatsuc)
except:
    print(tweetstatfail)